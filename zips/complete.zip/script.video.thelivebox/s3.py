#
#       Copyright (C) 2015-
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import datetime
import urllib
import re


start = ''
def mean(i, t1, t2=[]):
 t = start
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t


id = mean(12,[65,81],[77,53,251,65,84,66,94,86,232,79,13,72,87,75,210,67,80,79,157,90,189,85,45,65,189,51,201,73,36,73,125,65,240,73,234,75,251,65])

key = mean(0,[99,67,97,100,122,92,57,155,52,195,117,16,83,155,65,236,87,57,115],[163,80,168,87,134,120,253,82,60,69,195,99,30,97,46,119,73,74,248,77,161,107,49,106,83,77,89,103,53,115,211,43,52,47,156,52,118,66,215,72,7,83,253,109,40,48,17,43,7,71,174,81,140,55,247,97,77,101,138,90])


DELIMETER = '/'


def getSignature(resource, expires):
    import base64
    import hmac
    import sha

    HTTPVERB                = 'GET'
    ContentMD5              = ''
    ContentType             = ''
    CanonicalizedAmzHeaders = ''
    CanonicalizedResource   = '/thelivebox/%s' % resource

    string_to_sign = HTTPVERB + '\n' +  ContentMD5 + '\n' +  ContentType + '\n' + expires + '\n' + CanonicalizedAmzHeaders + CanonicalizedResource

    sig = base64.b64encode(hmac.new(key[::-1], string_to_sign, sha).digest())
    sig = urllib.urlencode({'Signature':sig})

    return sig


def convertToCloud(url):
    return url.replace('thelivebox.s3.amazonaws.com', 'd2blgl3q9xzi92.cloudfront.net')


def getExpires():
    days10  = 10 * 86400
    delta   = datetime.datetime.today() - datetime.datetime(1970,1,1)
    secs    = (delta.days * 86400) + (delta.seconds)
    secs    = int(secs / days10) * days10
    expires = secs + days10 + days10
    expires = str(expires)
    return expires


def getURL(resource='', marker=''):
    resource = fixResource(resource)
    prefix   = marker
    expires  = getExpires()
    sig      = getSignature(resource, expires) #encoding-type=url
    url      = 'http://thelivebox.s3.amazonaws.com/%s?&prefix=%s&marker=%s&AWSAccessKeyId=%s&Expires=%s&%s' % (resource, prefix, marker, id[::-1], expires, sig)

    return url

    
def getFile(folder, file):
    if not folder.endswith(DELIMETER):
        folder += DELIMETER

    return getURL(folder + file)


def fixResource(text):
    if text == '':
        return text

    import sfile

    root = sfile.getfolder(text, DELIMETER)
    path = sfile.getfilename(text, DELIMETER)

    if root == path:
        path = ''

    if path:
        path = DELIMETER + path
        path = urllib.quote_plus(path)

    url = root + path
   
    return url


def fix(text):
    ret = ''
    for ch in text:
        if ord(ch) < 128 and ord(ch) > -1:
            ret += ch   
        else:
            ret += '<%d>' % ord(ch)     
    return ret.strip()


def getFolder(folder):
    folders = []
    files   = []
    
    marker = folder
    while not marker == None:
        _folders, _files, marker = _getFolder(folder, marker)
        folders.extend(_folders)
        files.extend(_files)

    return folders, files


def _getFolder(folder, marker):
    import utils
    
    folders  = []
    files    = []

    if not folder.endswith(DELIMETER):
        folder += DELIMETER

    url = getURL(marker=marker)
  
    utils.Log('Amazon S3 URL : %s' % url)

    html = utils.GetHTML(url, maxAge = 3600)
    html = html.decode('utf-8')

    isTruncated = '<IsTruncated>true</IsTruncated>' in html  
        
    contents = re.compile('<Contents>(.+?)</Contents>').findall(html)
    key      = None

    for content in contents:
        try:
            key = re.compile('<Key>(.+?)</Key>').search(content).group(1)

            if key == folder:
                continue

            name = key.replace(folder, '', 1)
         
            if DELIMETER in name:
                thisFolder = folder + name.split(DELIMETER, 1)[0]
                if thisFolder not in folders:
                    folders.append(thisFolder)                
            else:
                try:    size = int(re.compile('<Size>(.+?)</Size>').search(content).group(1))
                except: size = 0
                files.append([key, size])
         
        except Exception, e:
            raise
            pass

    if not isTruncated:
        key = None

    return folders, files, key



def getAllFiles(folder, recurse=True):
    files = {}
 
    _getAllFiles(folder, files, recurse)

    return files


def _getAllFiles(theFolder, theFiles, recurse):
    if not theFolder.endswith(DELIMETER):
        theFolder += DELIMETER

    folders, files = getFolder(theFolder)

    if recurse:
        for folder in folders:
            _getAllFiles(folder, theFiles, recurse)

    for file in files:
        theFiles[file[0]] = file     