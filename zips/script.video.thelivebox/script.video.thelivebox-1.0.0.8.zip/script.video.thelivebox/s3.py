#
#       Copyright (C) 2015-
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import datetime
import urllib
import re


ooOOOoo = ''
def mean(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t


id = mean(12,[65,81],[77,53,251,65,84,66,94,86,232,79,13,72,87,75,210,67,80,79,157,90,189,85,45,65,189,51,201,73,36,73,125,65,240,73,234,75,251,65])

key = mean(0,[99,67,97,100,122,92,57,155,52,195,117,16,83,155,65,236,87,57,115],[163,80,168,87,134,120,253,82,60,69,195,99,30,97,46,119,73,74,248,77,161,107,49,106,83,77,89,103,53,115,211,43,52,47,156,52,118,66,215,72,7,83,253,109,40,48,17,43,7,71,174,81,140,55,247,97,77,101,138,90])


DELIMETER = '/'


def getSignature(resource, expires):
    import base64
    import hmac
    import sha

    HTTPVERB                = 'GET'
    ContentMD5              = ''
    ContentType             = ''
    CanonicalizedAmzHeaders = ''
    CanonicalizedResource   = '/thelivebox/%s' % resource

    string_to_sign = HTTPVERB + '\n' +  ContentMD5 + '\n' +  ContentType + '\n' + expires + '\n' + CanonicalizedAmzHeaders + CanonicalizedResource

    sig = base64.b64encode(hmac.new(key[::-1], string_to_sign, sha).digest())
    sig = urllib.urlencode({'Signature':sig})

    return sig


def getURL(resource=''):
    delta   = datetime.datetime.today() - datetime.datetime(1970,1,1)
    expires = (delta.days * 86400) + (delta.seconds) + (4 * 3600)
    expires = int(expires / 3600) * 3600
    expires = str(expires)

    sig = getSignature(resource, expires)
    url = 'http://thelivebox.s3.amazonaws.com/%s?AWSAccessKeyId=%s&Expires=%s&%s' % (resource, id[::-1], expires, sig)

    return url

    
def getFile(folder, file):
    if not folder.endswith(DELIMETER):
        folder += DELIMETER

    return getURL(folder + file)


def getFolder(folder):
    import utils

    folders  = []
    files    = []

    if not folder.endswith(DELIMETER):
        folder += DELIMETER

    url = getURL()

    utils.Log('Amazon S3 URL : %s' % url)

    content = utils.GetHTML(url, maxAge = 3600)
    keys    = re.compile('<Key>(.+?)</Key>').findall(content)

    for key in keys:
        if not key.startswith(folder):
            continue

        if key == folder:
            continue

        name = key.replace(folder, '', 1)
        
        if DELIMETER in name:
            thisFolder = folder + name.split(DELIMETER, 1)[0]
            if thisFolder not in folders:
                folders.append(thisFolder)
        else:
            files.append(key)

    return folders, files